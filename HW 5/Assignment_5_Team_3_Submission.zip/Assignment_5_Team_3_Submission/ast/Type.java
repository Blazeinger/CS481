package ast;

public abstract class Type extends Ast
{}
