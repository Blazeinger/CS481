package ast;

public abstract class Statement extends Ast {}
